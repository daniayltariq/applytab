<footer class="footer">
    <div class="footer-content">
        <p class="m-b-0">Copyright © 2023 ApplyTab All rights reserved.</p>
        
    </div>
</footer><?php /**PATH C:\laragon\www\applytab\resources\views/backend/partials/footbar.blade.php ENDPATH**/ ?>
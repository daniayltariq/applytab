
    <div class="confirm">
        <div></div>
        <div>
          <div id="confirmMessage">Confirm text</div>
          <div>
            <input class="confirm_input" id="confirmYes" type="button" value="Yes" />
            <input class="confirm_input" id="confirmNo" type="button" value="No" />
          </div>
        </div>
    </div><?php /**PATH C:\laragon\www\apply-tab\resources\views/backend/components/confirm-dialog.blade.php ENDPATH**/ ?>
<div class="overflow-y-auto relative scrollable" style="max-height: 300px">
    <?php $__currentLoopData = $all_notify; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notify): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a href="javascript:void(0);" class="dropdown-item d-block p-15 border-bottom">
            <div class="d-flex">
                <div class="avatar avatar-blue avatar-icon">
                    <i class="anticon anticon-mail"></i>
                </div>
                <div class="m-<?php echo e($alignShortRev); ?>-15">
                    <p class="m-b-0 text-dark"><?php echo e($notify->title ?? ''); ?></p>
                    <p class="m-b-0"><small><?php echo e(\Carbon\Carbon::parse($notify->created_at ?? '')->diffForHumans()); ?></small></p>
                </div>
            </div>
        </a>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div><?php /**PATH C:\laragon\www\applytab\resources\views/backend/partials/notification.blade.php ENDPATH**/ ?>
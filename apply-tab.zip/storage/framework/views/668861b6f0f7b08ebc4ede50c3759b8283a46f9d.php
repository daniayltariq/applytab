
<?php $__env->startSection('meta'); ?>
<title><?php echo e(config('app.name')); ?> | Dashboard</title>

<?php $__env->startSection('styles'); ?>
<style type="text/css"> 
    .fa{
        line-height: unset !important;
    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="main-content">

    <div class="page-header">
        <h2 class="header-title">Notifications</h2>
        <div class="header-sub-title">
            <nav class="breadcrumb breadcrumb-dash">
                <a href="<?php echo e(route('backend.dashboard')); ?>" class="breadcrumb-item"><i class="anticon anticon-home m-<?php echo e($alignShort); ?>-5"></i>Home</a>
                <a class="breadcrumb-item" href="<?php echo e(route('backend.view_notifications')); ?>">Notifications</a>
                <span class="breadcrumb-item active">List</span>
            </nav>
        </div>
    </div>
    <?php
    $icon=array(
            "contract"=>"tag",
            "guest"=>"user",
            "refund"=>"hand-holding-usd",
            "dispute"=>"exclamation-triangle",
            "info"=>"info-circle",
        );
    ?>
    <div class="card mb-4">
        <div class="card-body">
            <h2>Today</h2>
            <div class="list-group list-group-flush">
                <?php $__currentLoopData = $today; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notify): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $keys_exist= $notify->type && $notify->object ? true :false; 
                    ?>
                    <a href="javascript:void(0)" <?php if($keys_exist): ?>  <?php endif; ?> class="list-group-item list-group-item-action">
                        <div class="d-flex align-items-center" data-original-title="" title="">
                            <div>
                            
                                <span class="avatar"><i class="fa fa-<?php echo e($icon[$notify->type ?? 'info'] ?? ''); ?> text-primary"></i></span>
                            </div>
                            <div class="flex-fill ml-3">
                                <h6 class="fs-15 font-weight-600 mb-0"><?php echo e($notify->title ?? ''); ?> <small class="float-right text-muted"><?php echo e(\Carbon\Carbon::parse($notify->created_at ?? '')->diffForHumans()); ?></small></h6>
                                <p class="mb-0"><?php echo e($notify->body ?? ''); ?></p>
                            </div>
                        </div>
                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
            </div>
        </div>
    </div>

    <div class="card">
        <div class="card-body">
            <h2>Earlier</h2>
            <hr>
            <div class="list-group list-group-flush">
                <?php $__currentLoopData = $earlier; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $single): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $keys_exist= $single->type && $single->object ? true :false; 
                        ?>
                        <a href="javascript:void(0)" <?php if($keys_exist): ?>  <?php endif; ?> class="list-group-item list-group-item-action">
                            <div class="d-flex align-items-center" data-original-title="" title="">
                                <div>
                                    <span class="avatar"><i class="fa fa-<?php echo e($icon[$single->type ?? 'info'] ?? ''); ?> text-primary"></i></span>
                                </div>
                                <div class="flex-fill ml-3">
                                    <h6 class="fs-15 font-weight-600 mb-0"><?php echo e($single->title ?? ''); ?> <small class="float-right text-muted"><?php echo e(\Carbon\Carbon::parse($single->created_at ?? '')->diffForHumans()); ?></small></h6>
                                    <p class="mb-0"><?php echo e($single->body ?? ''); ?></p>
                                </div>
                            </div>
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   <hr>
                   <?php echo e($earlier->appends($_GET)->links()); ?>

            
            </div>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>

<script>
    $(document).ready(function(){
    })

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\applytab\resources\views/backend/notification/list.blade.php ENDPATH**/ ?>
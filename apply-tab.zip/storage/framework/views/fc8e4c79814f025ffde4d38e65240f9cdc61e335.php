<?php
    $auth_user=auth()->user();
?>
<div class="side-nav sidebar-bg">
    <div class="side-nav-inner">
        <?php if($auth_user->hasRole('superadmin') || ($auth_user->hasRole('customer')) ): ?>
        <ul class="side-nav-menu scrollable">
            <li class="nav-item <?php echo e(url()->current() == route('backend.dashboard') ? 'active' :''); ?>">
                <a href="<?php echo e(route('backend.dashboard')); ?>">
                    <span class="icon-holder">
                        <i class="fas fa-home"></i>
                    </span>
                    <span class="title">Home</span>
                </a>
            </li>
            <li class="nav-item <?php echo e(url()->current() == route('backend.institution.index') ? 'active' :''); ?>">
                <a href="<?php echo e(route('backend.institution.index')); ?>">
                    <span class="icon-holder">
                        <i class="fas fa-building"></i>
                    </span>
                    <span class="title">Institutions </span>
                </a>
            </li>
            <li class="nav-item <?php echo e(url()->current() == route('backend.job.index') ? 'active' :''); ?>">
                <a href="<?php echo e(route('backend.job.index')); ?>">
                    <span class="icon-holder">
                        <i class="fas fa-list-alt"></i>
                    </span>
                    <span class="title">Jobs </span>
                </a>
            </li>


            <li class="nav-item dropdown <?php echo e(\Route::is('backend.contract.*') ? 'active' :''); ?>">
                <a class="dropdown-toggle" href="javascript:void(0);">
                    <span class="icon-holder">
                        <i class="fas fa-list-alt"></i>
                    </span>
                    <span class="title">Reports</span>
                    <span class="arrow">
                        <i class="arrow-icon" style="color:#fff"></i>
                    </span>
                </a>
                <ul class="dropdown-menu">
                    <li>
                        <a href="#">Cost per Click</a>
                    </li>
                    <li>
                        <a href="#">Institutions</a>
                    </li>
                    <li>
                        <a href="#">Job Type</a>
                    </li>
                    <li>
                        <a href="#">Region</a>
                    </li>
                </ul>
            </li>

            <li class="nav-item <?php echo e(\Route::is('backend.view_notifications') ? 'active' :''); ?>">
                <a href="<?php echo e(route('backend.view_notifications')); ?>">
                    <span class="icon-holder">
                        <i class="fas fa-bell"></i>
                    </span>
                    <span class="title">Notifications </span>
                </a>
            </li>

       
            <li class="nav-item <?php echo e(url()->current() == route('backend.jobstats.index') ? 'active' :''); ?>">
                <a href="<?php echo e(route('backend.jobstats.index')); ?>">
                    <span class="icon-holder">
                        <i class="fas fa-list-alt"></i>
                    </span>
                    <span class="title">Job Stats </span>
                </a>
            </li>

            
            
            
           
        </ul>
        <?php endif; ?>
    </div>
</div><?php /**PATH C:\laragon\www\applytab\resources\views/backend/partials/sidebar.blade.php ENDPATH**/ ?>
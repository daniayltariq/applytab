<?php $request = app('Illuminate\Http\Request'); ?>
<!DOCTYPE html>
<html lang="en" >
    
    <head>
        <?php echo $__env->make('backend.partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        
        <?php echo $__env->yieldContent('styles'); ?>
        
        <style>
            
            * {
                font-family: "Quicksand";
            }

            .error{
                    color: red;
                }  

            body{
                font-family: -apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,"Helvetica Neue",Arial,sans-serif,"Apple Color Emoji","Segoe UI Emoji","Segoe UI Symbol";
            }

            .is-folded .side-nav .side-nav-inner .side-nav-menu>li>a.dropdown-toggle{
                padding-left: 15px !important;
            }

            .text-color1{
                color: white;
            }

            .text-color2{
                color: #66554b;
            }

            @media  only screen and (min-width: 992px)
            {
                .is-folded .header .logo h1.logo-unfold {
                    display: none;
                }
            }

            .anticon{
                line-height: unset !important;
            }

            .ft-size-17{
                font-size: 17px !important;
                line-height: 1.2 !important;
            }

            .logo{
                background-color: #485080 !important;
            }
            .stats-icon{
                font-size: 27px;
                color: rgba(47, 54, 95);
            }

            .stats-val{
                color: rgba(47, 54, 95);
            }

            .sidebar-bg{
                background-color: #485080 !important;
            }

            .side-nav .side-nav-inner .side-nav-menu li{
                margin-bottom: 10px;
            }
            .side-nav .side-nav-inner .side-nav-menu li:hover,.dropdown.open{
                background-color: #f9fbfd;
                border-radius: 16px 0 0 16px;
                margin-left: 0.5rem !important;
                /* margin-right: 0.5rem !important; */
            }

            .side-nav .side-nav-inner .side-nav-menu li.active{
                background-color: #f9fbfd;
                border-radius: 16px 0 0 16px;
                margin-left: 0.5rem !important;
                /* margin-right: 0.5rem !important; */
            }

            .side-nav .side-nav-inner .side-nav-menu li:after{
                border-right: unset;
                border-color: unset;
            }

            .side-nav .side-nav-inner .side-nav-menu,.header .logo{
                border-right: none !important;
            }

            .ps-container.ps-in-scrolling.ps-y>.ps-scrollbar-y-rail{
                background-color: none !important;
            }

            .ps-container.ps-in-scrolling.ps-y>.ps-scrollbar-y-rail>.ps-scrollbar-y{
                background-color: #dedede;
                width: 5px;
            }

        </style>
    </head>
    <!-- end::Head -->
    <!-- begin::Body -->
    <body>
        <div class="app">
            <div class="layout">
                <!-- begin:: BODY -->
                <?php echo $__env->make('backend.partials.extra', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php echo $__env->make('backend.partials.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <?php echo $__env->make('backend.partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <div class="page-container">
                    
                    <?php echo $__env->yieldContent('content'); ?>

                    <!-- begin:: Footer -->
                    <?php echo $__env->make('backend.partials.footbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <!-- end:: Footer -->           
                </div>
            </div>
        </div>
        <?php echo $__env->make('backend.components.confirm-dialog', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php echo $__env->make('backend.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->yieldContent('scripts'); ?>
    </body>
</html><?php /**PATH C:\laragon\www\applytab\resources\views/backend/layouts/app.blade.php ENDPATH**/ ?>
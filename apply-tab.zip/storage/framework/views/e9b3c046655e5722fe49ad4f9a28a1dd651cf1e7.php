<div class="modal-content">
    <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Update Job</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
        </button>
    </div>
    <?php
        $route=route('backend.job_update',['id'=>$job->id,'type'=>$type]);
    
    ?>
    <form action="<?php echo e($route); ?>" method="POST">
        <?php echo csrf_field(); ?>
        
        <div class="modal-body">
            <div class="kt-scroll" data-scroll="true">
                    
                <?php if(request()->type=='url'): ?>
                    <div class="form-group">
                        <label class="form-control-label">Apply Url</label>
                        <input type="text" class="form-control" name="url" value="<?php echo e(old('url') ?? ($job->apply_details ?? '')); ?>"/>
                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="error"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                <?php elseif(request()->type=='budget'): ?>
                    <div class="form-group">
                        <label class="form-control-label">Job Budget</label>
                        <input type="text" class="form-control" name="budget" value="<?php echo e(old('budget') ?? ($job->budget ?? '')); ?>"/>
                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="error"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                <?php endif; ?>
                
            </div>
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-primary">Update</button>
        </div>
    </form>
</div><?php /**PATH C:\xampp\htdocs\applytab\resources\views/backend/contract/component/modal.blade.php ENDPATH**/ ?>
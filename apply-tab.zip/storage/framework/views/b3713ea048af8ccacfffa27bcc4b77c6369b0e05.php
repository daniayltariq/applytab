<div class="modal-content">
    <div class="modal-header mx-auto">
        <h4 class="modal-title" id="exampleModalLabel"><?php echo e($type=='pixel' ? 'Job Pixel' : 'Update Job'); ?></h4>
        
        </button>
    </div>
    <?php if($type=='pixel'): ?>
        <div class="modal-body">
            <div class="row p-4">
                <div class="col-md-10 mx-auto">
                    <h4 style="color:#485080;font-weight: 800;">Here is your Tracking Pixel, now you can track webpage visits (page views).</h4>
                    <textarea class="codeblock w-100" onclick=" this.select() "><img src="<?php echo e(route('pixel.watch',$job->unique_id)); ?>"></textarea>
                </div>
            </div>
            
        </div>
        
    <?php else: ?>
        <?php
            $route=route('backend.job_update',['id'=>$job->id,'type'=>$type]);
        
        ?>
        <form action="<?php echo e($route); ?>" method="POST">
            <?php echo csrf_field(); ?>
            
            <div class="modal-body">
                <div class="kt-scroll" data-scroll="true">
                        
                    <?php if(request()->type=='url'): ?>
                        <div class="form-group">
                            <label class="form-control-label">Apply Url</label>
                            <input type="text" class="form-control" name="url" value="<?php echo e(old('url') ?? ($job->apply_details ?? '')); ?>"/>
                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="error"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    <?php elseif(request()->type=='budget'): ?>
                        <div class="form-group">
                            <label class="form-control-label">Job Budget</label>
                            <input type="text" class="form-control" name="budget" value="<?php echo e(old('budget') ?? ($job->budget ?? '')); ?>"/>
                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="error"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    <?php endif; ?>
                    
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-primary">Update</button>
            </div>
        </form>
    <?php endif; ?>
        
</div><?php /**PATH C:\laragon\www\apply-tab\resources\views/backend/contract/component/modal.blade.php ENDPATH**/ ?>
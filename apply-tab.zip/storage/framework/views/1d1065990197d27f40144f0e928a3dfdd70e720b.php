<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<title><?php echo e(config('app.name')); ?> - Admin Dashboard </title>

<!-- Favicon -->


<!-- page css -->
<link href="<?php echo e(asset('backend/assets/vendors/bootstrap-datepicker/bootstrap-datepicker.min.css')); ?>" rel="stylesheet">

<!-- Core css -->
<link href="<?php echo e(asset('backend/assets/css/app.min.css')); ?>" rel="stylesheet">

<link href="<?php echo e(asset('css/confirm-dialog.css')); ?>" rel="stylesheet">

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.css">
<link href='https://fonts.googleapis.com/css?family=Quicksand' rel='stylesheet'><?php /**PATH C:\laragon\www\applytab\resources\views/backend/partials/header.blade.php ENDPATH**/ ?>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<title>{{config('app.name')}} - Admin Dashboard </title>

<!-- Favicon -->
{{-- <link rel="shortcut icon" href="{{asset('backend/assets/images/logo/favicon.png')}}"> --}}

<!-- page css -->
<link href="{{asset('backend/assets/vendors/bootstrap-datepicker/bootstrap-datepicker.min.css')}}" rel="stylesheet">

<!-- Core css -->
<link href="{{asset('backend/assets/css/app.min.css')}}" rel="stylesheet">

<link href="{{asset('css/confirm-dialog.css')}}" rel="stylesheet">

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.css">
<link href='https://fonts.googleapis.com/css?family=Quicksand' rel='stylesheet'>
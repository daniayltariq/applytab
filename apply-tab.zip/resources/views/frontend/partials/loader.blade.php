<div class="preloader">
    <img src="{{asset('frontend/assets/images/loading-logo.svg')}}" alt="image">
</div>
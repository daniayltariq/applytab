<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<title>Sanad App | The Best House Services Platform In KSA!</title>

<link rel="apple-touch-icon" sizes="180x180" href="{{asset('frontend/assets/favicon/apple-touch-icon.png')}}">
<link rel="icon" type="image/png" sizes="32x32" href="{{asset('frontend/assets/favicon/favicon-32x32.png')}}">
<link rel="icon" type="image/png" sizes="16x16" href="{{asset('frontend/assets/favicon/favicon-16x16.png')}}">

<!--stylesheet-->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
<link rel="stylesheet" href="{{asset('frontend/assets/css/all.min.css')}}">
<link rel="stylesheet" href="{{asset('frontend/assets/css/swiper-bundle.min.css')}}">
<link rel="stylesheet" href="{{asset('frontend/assets/css/style.css')}}">

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.css">
<?php

return [

    /**
     * Set your FCM Server Key
     * Change to yours
     */

    'server_key' => env('FCM_SERVER_KEY', 'AAAA8XFCjYM:APA91bEdHvvqQQvZsThrHbdvTBYVbDrEP9ALPbYAVAYxJjnJst0iSNGiIwbcAopHxH3JmT1px4bPS6vtTzzSP8E3Wx1ASXgmC1ZchWgC25dzOhR6uAPttNwYO_16M3ZZsWVyaDfFpBCX'),

];
